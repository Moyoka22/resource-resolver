# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['resource_resolver', 'resource_resolver.core', 'resource_resolver.utils']

package_data = \
{'': ['*']}

install_requires = \
['boto3>=1.18.1,<2.0.0', 'pyarrow>=5.0.0,<6.0.0']

setup_kwargs = {
    'name': 'resource-resolver',
    'version': '0.3.0',
    'description': 'Provides tools to abstract away resource I/O.',
    'long_description': None,
    'author': 'Moye Odiase',
    'author_email': 'moye-odiase@element-energy.co.uk',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
